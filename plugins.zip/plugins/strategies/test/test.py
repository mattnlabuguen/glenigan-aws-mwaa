import logging

import pandas as pd

from utils.strategy_factory import StrategyFactory

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')


if __name__ == '__main__':
    website = 'planning.hillingdon.gov.uk'
    strategy_factory = StrategyFactory(website)

    source = strategy_factory.get_source_strategy()
    crawler = strategy_factory.get_crawl_strategy()
    parser = strategy_factory.get_parse_strategy()

    sources = source.get_sources(months_ago=1)
    raw_data_list = []
    for source in sources:
        raw_data_list.append(crawler.crawl(source))

    parsed_data_list = []
    for raw_data in raw_data_list:
        parsed_data_list.append(parser.parse(raw_data))

    df = pd.DataFrame(parsed_data_list)
    df.to_csv(f'output/{website.replace(".", "_")}_parsed_data.csv', index=False)