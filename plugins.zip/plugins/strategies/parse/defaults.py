from enum import Enum


class Defaults(Enum):
    NOT_FOUND = 'None'
    EXTRACTION_ERROR = 'EXTRACTION_ERROR'
